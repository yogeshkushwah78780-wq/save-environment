document.getElementById('contactForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    alert("Vastroofit Support: Your message has been sent successfully!");
    this.reset();
});